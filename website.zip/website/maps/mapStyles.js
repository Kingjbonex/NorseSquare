

var greenStyle = [
  {
    elementType: "labels",
    stylers: [
      { visibility: "off" }
    ]
  },{
    stylers: [
      { hue: "#004cff" },
      { saturation: -42 }
    ]
  }
];