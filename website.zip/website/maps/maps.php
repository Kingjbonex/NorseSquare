<?php echo $_POST; ?>

<html> 
<head> 
	<link rel="stylesheet" type="text/css" href="stylesheet.css" />
   <meta http-equiv="content-type" content="text/html; charset=UTF-8"/> 
   <title>NorseSquare</title> 
   <script src="http://www.parsecdn.com/js/parse-1.1.14.min.js"></script>



<script type="text/javascript">
(function() {
    if (typeof window.janrain !== 'object') window.janrain = {};
    if (typeof window.janrain.settings !== 'object') window.janrain.settings = {};
    
    janrain.settings.tokenUrl = 'http://norsesquare.com';

    function isReady() { janrain.ready = true; };
    if (document.addEventListener) {
      document.addEventListener("DOMContentLoaded", isReady, false);
    } else {
      window.attachEvent('onload', isReady);
    }

    var e = document.createElement('script');
    e.type = 'text/javascript';
    e.id = 'janrainAuthWidget';

    if (document.location.protocol === 'https:') {
      e.src = 'https://rpxnow.com/js/lib/luther-bargain-books/engage.js';
    } else {
      e.src = 'http://widget-cdn.rpxnow.com/js/lib/luther-bargain-books/engage.js';
    }

    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(e, s);
})();
</script>



</head> 
<body onLoad="starter();">     
	<div id="mainDiv">
  <a id="janrainLink" class="janrainEngage" href="#"></a>
	<div id="map" style="width: 100%; height: 600px; float:right;"></div> 
  
  </div>   
</body> 

   <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
   <script type="text/javascript" src="markers.js"> </script>
   <script type="text/javascript" src="polygons.js"> </script>
   <script type="text/javascript" src="mapStyles.js"> </script>
   <script type="text/javascript" src="jquery.js"></script>
   <script type="text/javascript" src="maps.js"></script>



</html>

<?php 
?>

